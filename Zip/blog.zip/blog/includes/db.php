<?php 
    define("SERVER", 'localhost');
    define("USER", 'Nikhil');
    define("PASSWORD", 'n20081998');
    define("DB", 'cms');

    $connection = mysqli_connect(SERVER, USER, PASSWORD, DB);
//    if($connection){
//        echo "We are Connected! <br>";
//    }
?>